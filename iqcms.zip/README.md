# iqcms
## **_Intelligent Content Management Systems_**



// IQ CMS 0.4.1 by Otismo Web Design (http://iqcms.com/owd/)


	Thank you for downloading IQ CMS.


// Setup - Here's a quick start how to setup IQ CMS.



1. Extract the iqcms-0.4.1.zip

2. Upload all the files to your server. That's it.

3. Open up the page where you uploaded the files.

4. A file named PageName-side.txt must be added to the Files folder for every new page.



For support or questions visit http://iqcms.com/

---



// Attribution



IQ CMS is a fork in the development path of 

(right now, it is a clone or exact branded copy of)

Wonder CMS 0.4.1 by Robert Isoski (http://krneky.com)

The Wonder CMS Forum is at http://krneky.com/forum



// Contributors



- Robert Isoski - http://krneky.com (for Wonder CMS)

- Michael Driggs

- Tom Wong - http://odcms.net

- Wolfram Fiedler - http://wfiedler-online.de

- Kalyan Chakravarthy - http://kalyanchakravarthy.net

- Yvo Schaap - http://yvoschaap.com (for editInplace.js) 

- Darren Hester - http://www.designsbydarren.com (for Technology Blog Template)

- Otis Schmakel - http://iqcms.com/owd (for Conway's GoL FAVICON - Jan Kok's Galaxy)

- rocktronica - http://onefilecms.com (for the Original, Smallest, One File CMS)

- Rinalds Uzkalns - http://www.rinalds.com (for PHP Unzipper v1.1)
 
- Vincent Blavet - http://www.phpconcept.com. (for PhpConcept Zip Module 1.3)



// License -  http://creativecommons.org/licenses/by/3.0/
