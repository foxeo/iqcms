// IQ CMS 0.4.1 by Otismo Web Design (http://iqcms.com/owd/)



	Hey there :), thank you for downloading IQ CMS.



// Setup - Here's a quick start on how to setup IQ CMS.



1. Extract the iqcms-0.4.1.zip

2. Upload all the files to your server. That's it.
 
3. Open up the page where you uploaded the files.

4. Everything should work just fine - but if you

are getting errors when trying to navigate to pages,

you may have to edit your .htaccess file:

In cases where IQ CMS does not run 

from the root folder of a domain, 

you will have to change the "RewriteBase" line 

to something like this:

RewriteBase /path/to/iqcmsfolder/


For support or questions visit http://iqcms.com/

---



// Attribution



IQ CMS is a fork in the development path of 

(right now, it is a clone or exact branded copy of)

Wonder CMS 0.4.1 by Robert Isoski (http://krneky.com)

The Wonder CMS Forum is at http://krneky.com/forum



// Contributors



- Robert Isoski - http://krneky.com (for Wonder CMS)

- Michael Driggs

- Tom Wong - http://odcms.net

- Wolfram Fiedler - http://wfiedler-online.de

- Kalyan Chakravarthy - http://kalyanchakravarthy.net

- Yvo Schaap - http://yvoschaap.com (for editInplace.js) 



// License -  http://creativecommons.org/licenses/by/3.0/